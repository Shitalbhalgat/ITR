<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Attendance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="style.css" rel="stylesheet"/>
<style>
        .myattend {
            display: block;
            margin: 30px auto;
            max-width: 1000px;
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .info-section {
            max-width: 1000px;
            margin: 30px auto;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }

        .info-section h2 {
            color: #333;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        .info-section h4 {
            margin-top: 20px;
            color: #444;
        }

        .info-section li {
            margin: 10px 0;
            line-height: 1.6;
        }

        .info-section i {
            color: #007bff;
            margin-right: 8px;
        }

    </style>
</head>
<body>
    <div class="page-container">
        <?php require("Navbar.php"); ?>
      <div class="content-wrap">
            <img src="../image/attendance.jpg" alt="photo" class="myattend">

          <div class="info-section">
            <h2><i class="fas fa-cogs"></i> How It Works</h2>
            <p>Our Employee Attendance System is designed to be simple and user-friendly. Here’s a quick overview:</p>
            <ol>
                <li><i class="fas fa-sign-in-alt"></i> <strong>Log in</strong> using your employee credentials.</li>
                <li><i class="fas fa-user-check"></i> <strong>Check In</strong> at the start of your shift.</li>
                <li><i class="fas fa-user-clock"></i> <strong>Check Out</strong> before leaving work.</li>
                <li><i class="fas fa-calendar-alt"></i> <strong>View Attendance</strong> from your profile.</li>
            </ol>
          </div>

           <div class="info-section">
                <h2><i class="fas fa-user-edit"></i> How to Mark Your Attendance</h2>
                <p>Follow these simple steps to record your daily attendance:</p>
                <ol>
                    <li><i class="fas fa-home"></i> Navigate to the <strong>Dashboard</strong> after login.</li>
                    <li><i class="fas fa-user-check"></i> Click the <strong>Check In</strong> button.</li>
                    <li><i class="fas fa-user-clock"></i> Click the <strong>Check Out</strong> button to finish.</li>
                </ol>
                <p><em>Example dashboard:</em></p>
                <img src="dashboard-screenshot.jpg" alt="Dashboard Screenshot" style="width:100%; max-width:600px; border-radius:8px; margin:10px 0;">
          </div>

            <div class="info-section">
                <h2><i class="fas fa-question-circle"></i> Frequently Asked Questions (FAQs)</h2>

                <h4><i class="fas fa-clock"></i> What if I forget to check in?</h4>
                <p>You can request a manual update by contacting your manager or HR through the “Contact HR” section.</p>

                <h4><i class="fas fa-edit"></i> Can I edit my attendance?</h4>
                <p>No, employees cannot edit their own attendance. Please request changes via HR.</p>

                <h4><i class="fas fa-check-circle"></i> How do I know if my attendance was recorded?</h4>
                <p>Check the “Attendance History” page. Issues will be flagged in red or with a warning icon.</p>
            </div>
         </div>
        </div>
        
    <div class="footer">
            <p>© Employee Attendance System</p> 
    </div>
</div>
</body>
</html>
