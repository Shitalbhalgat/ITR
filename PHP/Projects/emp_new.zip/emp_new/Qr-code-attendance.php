<?php
session_start();

if (!isset($_SESSION['username'])) 
  {
    header("Location: userlogin.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Employee Attendance QR Scanner</title>
  <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="style.css" rel="stylesheet">
<style>
    .container {
      background: white;
      color: #333;
      max-width: 400px;
      margin: auto;
      border-radius: 10px;
      padding: 30px;
    }
    #reader {
      width: 100%;
      margin-bottom: 15px;
    }
      h2 {
      color: #007BFF;
      
    }
    button {
      background: skyblue;
      border: none;
      color: white;
      padding: 12px 25px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      margin: 5px;
       transition: background 0.3s ease;
    }

      #inBtn {
        background-color: #28a745; 
      }

      #inBtn:hover {
        background-color: #218838;
      }

      #outBtn {
        background-color: #dc3545;
      }

      #outBtn:hover {
        background-color: #c82333;
      }
          
      #result {
        color: #007BFF;
    
        font-weight: bold;
        margin-top: 20px;
        text-align: center;
        font-size: 18px;
      }

  </style>
</head>
<body>
  <div class="page-container">
    <?php require("Navbar.php"); ?>
      <div class="content-wrap">
          <div class="container">
              <h2>Scan QR to Clock In / Clock Out</h2>
              <div style="text-align:center;">
                <button id="inBtn"><i class="fas fa-sign-in-alt"></i> Clock In</button>
                <button id="outBtn"><i class="fas fa-sign-out-alt"></i> Clock Out</button>
              </div>
              <div id="reader"></div>
              <div id="result">Select an action and scan QR.</div>
           </div>
      </div>

      <div class="footer">
            <p>© Employee Attendance System</p>
      </div>
  </div>

  <script>
    let lastScannedId = null;
    let currentAction = 'in';

    document.getElementById('inBtn').onclick = (e) => {
      e.preventDefault();
      currentAction = 'in';
      document.getElementById('result').innerText = "Ready to Clock In - Scan QR";
    };

    document.getElementById('outBtn').onclick = (e) => {
      e.preventDefault();
      currentAction = 'out';
      document.getElementById('result').innerText = "Ready to Clock Out - Scan QR";
    };

    function onScanSuccess(qrCodeMessage) {
      if (qrCodeMessage === lastScannedId) return; // prevent duplicate scan
      lastScannedId = qrCodeMessage;

      fetch('mark_attendance.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'employee_id=' + encodeURIComponent(qrCodeMessage) + '&action=' + currentAction
      })
      .then(response => response.text())
      .then(data => {
        const resultDiv = document.getElementById('result');
        const success = data.toLowerCase().includes("recorded");

        resultDiv.innerText = data;
        resultDiv.style.color = success ? 'green' : 'red';

        // Allow rescan after a few seconds
        setTimeout(() => {
          lastScannedId = null;
        }, 3000);
      });
    }

    const html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
    html5QrcodeScanner.render(onScanSuccess);
  </script>
</body>
</html>
