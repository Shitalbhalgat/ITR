  <div class="header">
        EMPLOYEE ATTENDANCE SYSTEM
    </div>

    <div class="navbar">
        <a href="index.php">HOME</a>
        <a href="Qr-code-attendance.php">ADD ATTENDANCE</a>
        <a href="userreports.php">REPORT</a>
         <a href="profile.php">MY PROFILE</a>
         <?php if (!isset($_SESSION['username'])): ?>
                <a href="userlogin.php">LOGIN</a>
        <?php else: ?>
                <a href="logout.php">LOGOUT</a>
        <?php endif; ?>
        
        <a href="aboutus.php">ABOUT US</a>
        <a href="contactus.php">CONTACT</a>

     </div>
