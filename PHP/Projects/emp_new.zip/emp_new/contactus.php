<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - Employee Attendance System</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .contact-container {
      max-width: 800px;
      margin: 50px auto;
      padding: 30px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px #ccc;
      font-family: Arial, sans-serif;
    }

    h1 {
      color: #007BFF;
      text-align: center;
    }

    label {
      display: block;
      margin-top: 15px;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    input[type="submit"] {
      background-color:#00aaFF;
      color: white;
      font-weight: bold;
      margin-top: 20px;
      cursor: pointer;
    }
  </style>
</head>
<body>

<?php include("Navbar.php"); ?>

<div class="contact-container">
     <h1>Contact Us</h1>
    <form method="post" action="">
    <label>Name</label>
    <input type="text" name="name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Message</label>
    <textarea name="message" rows="5" required></textarea>

    <input type="submit" name="submit" value="Send Message">
  </form>
</div>

<div class="footer">
  <p>© Employee Attendance System</p>
</div>


</body>
</html>
