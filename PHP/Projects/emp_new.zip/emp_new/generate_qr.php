<?php
include "phpqrcode/qrlib.php";

$employee_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($employee_id === 0) {
    die("Invalid employee ID.");
}

$filename = "qr_$employee_id.png";
QRcode::png($employee_id, $filename);

echo "<h3>QR Code for Employee ID: $employee_id</h3>";
echo "<img src='$filename'>";
/*
<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die("Access denied. <a href='admin_login.php'>Login</a>");
}

include "phpqrcode/qrlib.php";
$conn = new mysqli("localhost", "root", "", "qr_attendance");

$employee_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($employee_id === 0) {
    die("Invalid employee ID.");
}

// Check employee exists
$check = $conn->prepare("SELECT name FROM employees WHERE id = ?");
$check->bind_param("i", $employee_id);
$check->execute();
$check->store_result();
if ($check->num_rows === 0) {
    die("Employee does not exist.");
}

$filename = "qr_$employee_id.png";
QRcode::png($employee_id, $filename);

echo "<h3>QR Code for Employee ID: $employee_id</h3>";
echo "<img src='$filename'>";
echo "<br><a href='admin_dashboard.php'>Back to Dashboard</a>";
*/
?>
