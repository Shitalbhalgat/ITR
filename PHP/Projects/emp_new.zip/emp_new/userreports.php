<?php
require('db_connection.php');
session_start();

if (!isset($_SESSION['username'])) 
  {
    header("Location: userlogin.php");
    exit();
  }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee Reports</title>
    <link href="style.css" rel="stylesheet">
    <style>
        table {
           
            border-collapse: collapse;
        }
        thead {
            background-color: skyblue;
            color: white;
        }
        th, td {
            padding: 30px;
            text-align: center;
            border: 1px solid #000;
        }
        .emp-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        
       
    </style>
</head>
<body>
<body>
  <div class="page-container">
    <?php require("Navbar.php"); ?>
     <div class="content-wrap">
        <center><h2>EMPLOYEE REPORTS</h2>
    <table>
        <thead>
            <tr>
                <th>Sr. No.</th>
                <th>Employee Name</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $username = $_SESSION['username'];
        $query = "SELECT attendance.id,
                    employees.name,
                    attendance.date,
                    attendance.time_in,
                    attendance.time_out
                  FROM attendance
                  JOIN employees ON attendance.employee_id = employees.id where employees.name = '$username'";

        $result = mysqli_query($conn, $query);
        $sr = 1;

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>{$sr}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['date']}</td>
                        <td>{$row['time_in']}</td>
                        <td>{$row['time_out']}</td>
                      </tr>";
                $sr++;
            }
        } else {
            echo "<tr><td colspan='5'>No attendance records found.</td></tr>";
        }

        mysqli_close($conn);
        ?>
        </tbody>

    </table>
    </center>
</div>

<div class="footer">
    <p>© Employee Attendance System</p>
</div>

</body>
</html>
