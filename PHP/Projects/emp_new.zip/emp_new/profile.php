<?php
session_start();
require('db_connection.php');
if (!isset($_SESSION['username'])) {
    header("Location: userlogin.php");
    exit();
}

$username = $_SESSION['username'];

$query = "SELECT * FROM employees WHERE Email = '$username'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("User not found.");
}

$user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .profile-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            box-shadow: 0 0 10px #ccc;
            border-radius: 10px;
            text-align: center;
        }

        .profile-img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
        }

        .profile-info {
            text-align: left;
            margin-top: 20px;
        }

        .profile-info p {
            margin: 10px 0;
            font-size: 16px;
        }

        .profile-info span {
            font-weight: bold;
        }
    </style>
</head>
<body>

<?php include('Navbar.php'); ?>

<div class="profile-container">
    <img src="<?php echo !empty($user['image']) ? $user['image'] : 'default.png'; ?>" class="profile-img" alt="Profile Picture">

    <h2><?php echo $user['name']; ?></h2>

    <div class="profile-info">
        <p><span>Username:</span> <?php echo $user['name']; ?></p>
        <p><span>Email:</span> <?php echo $user['Email']; ?></p>
        <p><span>Mobile:</span> <?php// echo $user['mobile']; ?></p>
        <p><span>Blood Group:</span> <?php //echo $user['blood_group']; ?></p>
        <p><span>Date of Birth:</span> <?php //secho date("d M, Y", strtotime($user['dob'])); ?></p>
    </div>
</div>

</body>
</html>
