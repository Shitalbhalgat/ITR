<?php

$correct_username = "admin";
$correct_password = "admin123";

$error_message = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_username = $_POST["username"];
    $entered_password = $_POST["password"];

    if ($entered_username === $correct_username && $entered_password === $correct_password) {
       
        header("Location: adminhome.php");
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }
}
?>


<html>
<head>
    <title>Login Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: skyblue;
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
        }
        .box {
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px ;
            width: 300px;
            text-align: center;
        }
        input[type="text"], input[type="password"] {
          background-color:#black;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            font-size: 16px;
        }
        .error {
            color: red;
}
       input[type="submit"]{
         background-color:skyblue;
         color:white;
         width: 100%;
            padding: 10px;
            margin: 10px 0;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Login For Admin</h2>

    <?php if (!empty($error_message)): ?>
        <p class="error"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form method="post">
        <input type="text" name="username" placeholder="Enter username" >
        <input type="password" name="password" placeholder="Enter password" >
        <input type="submit" value="Login">
    </form>
</div>

</body>
</html>
<?php
session_start();
$conn = new mysqli("localhost", "root", "", "qr_attendance");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($admin_id, $hashed);
    if ($stmt->fetch() && password_verify($password, $hashed)) {
        $_SESSION['admin_id'] = $admin_id;
        header("Location: admin_dashboard.php");
        exit;
    } else {
        $error = "Invalid credentials";
    }
}
?>

<form method="post">
    <h2>Admin Login</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <label>Username:</label><input type="text" name="username"><br>
    <label>Password:</label><input type="password" name="password"><br>
    <button type="submit">Login</button>
</form>
<?php
session_start();

$admin_user = "admin";
$admin_pass = "admin123";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["username"] === $admin_user && $_POST["password"] === $admin_pass) {
        $_SESSION['admin_username'] = $admin_user;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "Invalid admin credentials.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
  <style>
    body { font-family: Arial; background: #f2f2f2; display: flex; justify-content: center; align-items: center; height: 100vh; }
    .login-box {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px #ccc;
      width: 300px;
      text-align: center;
    }

    input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
    }

    button {
      background-color: skyblue;
      color: white;
      border: none;
      padding: 10px;
      width: 100%;
    }

    .error { color: red; }
  </style>
</head>
<body>

<div class="login-box">
  <h2>Admin Login</h2>
  <?php if ($error): ?>
    <p class="error"><?= $error ?></p>
  <?php endif; ?>

  <form method="post">
    <input type="text" name="username" placeholder="Admin Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
  </form>
</div>

</body>
</html>
