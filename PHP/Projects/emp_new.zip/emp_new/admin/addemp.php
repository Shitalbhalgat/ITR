<?php
session_start();

// Only allow logged-in admins
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "attendance_db");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$success = "";
$error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];
    $blood_group = $_POST["blood_group"];
    $dob = $_POST["dob"];

    $sql = "INSERT INTO employees (name, email, mobile, blood_group, dob)
            VALUES ('$name', '$email', '$mobile', '$blood_group', '$dob')";

    if (mysqli_query($conn, $sql)) {
        $success = "Employee added successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            padding: 30px;
        }

        .form-box {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 25px;
            box-shadow: 0 0 10px #ccc;
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background: skyblue;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }

        .message {
            text-align: center;
            font-weight: bold;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        .back-link {
            text-align: center;
            margin-top: 15px;
        }

        .back-link a {
            text-decoration: none;
            color: #007BFF;
        }
    </style>
</head>
<body>

<div class="form-box">
    <h2>Add New Employee</h2>

    <?php if ($success): ?>
        <p class="message success"><?= $success ?></p>
    <?php elseif ($error): ?>
        <p class="message error"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Full Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Mobile</label>
        <input type="text" name="mobile" required>

        <label>Blood Group</label>
        <input type="text" name="blood_group" required placeholder="e.g. B+ve">

        <label>Date of Birth</label>
        <input type="date" name="dob" required>

        <button type="submit">Add Employee</button>
    </form>

    <div class="back-link">
        <a href="admin_employees.php">← Back to Employee List</a>
    </div>
</div>

</body>
</html>
