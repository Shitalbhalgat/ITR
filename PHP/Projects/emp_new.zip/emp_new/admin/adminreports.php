
<head>
    <meta charset="UTF-8">
    <title>Admin Report - Employee Attendance System</title>
      <link href="../CSS/style.css" rel ="stylesheet"/>
    <style>

        .content {
            background-color: white;
            padding: 30px;
            margin: 50px auto;
            width:100%;
            max-width: 1000px;
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: skyblue;
            color: white;
        }

        .footer {
            text-align: center;
            padding: 20px;
            color: white;
        }

        

        
    </style>
</head>
<body>
   <?php  require("adminNavbar.php");?>

    <div class="content">
        <h2>Admin Report Dashboard</h2>
        <p>Below is the attendance report of employees:</p>

        <table>
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Check-in</th>
                    <th>Check-out</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>EMP001</td>
                    <td>Samrin Pathan</td>
                    <td>2025-08-14</td>
                    <td>09:00 AM</td>
                    <td>05:00 PM</td>
                    <td>Present</td>
                </tr>
                <tr>
                    <td>EMP002</td>
                    <td>Mrunal More</td>
                    <td>2025-08-14</td>
                    <td>09:15 AM</td>
                    <td>05:10 PM</td>
                    <td>Late</td>
                </tr>
 <tr>
                    <td>EMP003</td>
                    <td>Anushka Matsagar</td>
                    <td>2025-08-14</td>
                    <td>09:15 AM</td>
                    <td>05:10 PM</td>
                    <td>absent</td>
                </tr>
 <tr>
                    <td>EMP004</td>
                    <td>Sanika Pawar</td>
                    <td>2025-08-14</td>
                    <td>09:15 AM</td>
                    <td>05:10 PM</td>
                    <td>Late</td>
                </tr>
 <tr>
                    <td>EMP005</td>
                    <td>Sayali Jadhav</td>
                    <td>2025-08-14</td>
                    <td>09:15 AM</td>
                    <td>05:10 PM</td>
                    <td>Late</td>
                </tr>
                <!-- Add more rows as needed -->
            </tbody>
        </table>
    </div>

    <div class="footer">© Employee Attendance System</div>

</body>
</

<?php
session_start();

// Only allow admin access
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}

// DB connection
$conn = mysqli_connect("localhost", "root", "", "attendance_db");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// JOIN employees and attendance tables
$sql = "SELECT a.id, a.date, a.time_in, a.time_out, e.name, e.email 
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        ORDER BY a.date DESC, a.time_in DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Attendance Records</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px #ccc;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: skyblue;
            color: white;
        }

        .no-records {
            text-align: center;
            padding: 20px;
            font-weight: bold;
            color: red;
        }

        .back-link {
            text-align: center;
            margin-top: 15px;
        }

        .back-link a {
            text-decoration: none;
            color: #007BFF;
        }
    </style>
</head>
<body>

<h2>Attendance Records</h2>

<table>
    <thead>
        <tr>
            <th>Record ID</th>
            <th>Employee Name</th>
            <th>Email</th>
            <th>Date</th>
            <th>Time In</th>
            <th>Time Out</th>
        </tr>
    </thead>
    <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= $row['date'] ?></td>
                    <td><?= $row['time_in'] ?></td>
                    <td><?= $row['time_out'] ?? '-' ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" class="no-records">No attendance records found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="back-link">
    <a href="admin_employees.php">← Back to Employee Management</a>
</div>

</body>
</html>
