<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $blood_group = $_POST["blood_group"];
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];
    $dob = $_POST["dob"];
    $address1 = $_POST["address1"];
    $address2 = $_POST["address2"];
    $country = $_POST["country"];
    $state = $_POST["state"];
     $city = $_POST["city"];

    if (isset($_FILES["photo"])) {
        $targetDir = "uploads/";
        if (!file_exists($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $fileName = basename($_FILES["photo"]["name"]);
        $targetFile = $targetDir . $fileName;
        move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFile);
    }

    echo "<h2>Employee Registered Successfully!</h2>";
    echo "<p><strong>Name:</strong> $name</p>";
    echo "<p><strong>Email:</strong> $email</p>";
    echo "<p><strong>Mobile:</strong> $mobile</p>";
    echo "<p><strong>City:</strong> $city</p>";
}
?>

<!DOCTYPE html>
<html >
<head>
 
    <title>Employee Registration</title>

</head>
<style>
body{
  body {
    font-family: Arial, sans-serif;
    background-color: #000000;
}

.container {
    width: 400px;
    margin: 40px auto;
    padding: 20px;
    background-color: #c0c0c0;
    border: 2px solid #000000;
}

h2 {
    text-align: center;
    color: #800000;
}

form label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
}

form input[type="text"],
form input[type="email"],
form input[type="date"],
form select,
form input[type="file"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    box-sizing: border-box;
}

.buttons {
    margin-top: 15px;
    display: flex;
    justify-content: space-between;
}

button {
    padding: 10px 20px;
    border: 1px;
    color: white;
    cursor: pointer;
}

button[type="submit"] {
    background-color: #800000;
}

.reset-btn {
    background-color:#000000;
}

}
</style>
<div class="container">
    <h2>Employee Registration</h2>
    <form action="adminhome.php" method="POST" 
        <label><b>Name:</b></label>
        <input type="text" name="name" >

        <label>Blood Group:</label>
        <input type="text" name="blood_group" >

        <label>Mobile:</label>
        <input type="text" name="mobile">

        <label>Email:</label>
        <input type="email" name="email">

        <label>Date of Birth:</label>
        <input type="date" name="dob" required>

        <label>Address Line 1:</label>
        <input type="text" name="address1">

        <label>Address Line 2:</label>
        <input type="text" name="address2">

        

       

        <label>Country:</label>
        <select name="country" required>
            <option value="">Please Select</option>
            <option value="India">India</option>
          
        </select>

         <label>State:</label>
        <select name="state" >
            <option value="">Please Select</option>
            <option value="Maharashtra">Maharashtra</option>
            <option value="Rajasthan">Rajasthan</option>
            <option value="Tamilnadu">Tamilnadu</option>
            <option value="Punjab">Punjab</option>
            <option value="Gujrat">Gujrat</option>
        </select>

        <label>City:</label>
        <select name="city" required>
            <option value="">Please Select</option>
            <option value="Ahmednagar">Ahmednagar</option>
            <option value="Pune">Pune</option>
            <option value="Nashik">Nashik</option>
            <option value="Ratnagira">Ratnagiri</option>
            <option value="Sambhajinagar">Sambhajinagar</option>
        </select>

        <label>Photo:</label>
        <input type="file" name="photo" required>

        <div class="buttons">
            <button type="submit">Submit</button>
            <button type="reset" class="reset-btn">Reset</button>
        </div>
    </form>
</div>
</body>
</html>



<form method="post">
    <input type="text" name="name" placeholder="Full Name" required><br>
    <input type="text" name="employee_code" placeholder="Employee Code (optional)"><br>
    <input type="text" name="department" placeholder="Department"><br>
    <input type="text" name="designation" placeholder="Designation"><br>
    <input type="email" name="email" placeholder="Email (optional)"><br>
    <input type="text" name="phone" placeholder="Phone (optional)"><br>
    <input type="date" name="date_joined" value="<?= date('Y-m-d') ?>"><br>
    <button type="submit">Register Employee</button>
</form>
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    employee_code VARCHAR(20),
    department VARCHAR(50),
    designation VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(15),
    date_joined DATE,
    status ENUM('active', 'inactive') DEFAULT 'active'
);
