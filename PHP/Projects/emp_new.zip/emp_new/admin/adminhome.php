<html>
<head>
    <title>Employee Attendance System</title>
    <link href="../CSS/style.css" rel ="stylesheet"/>
</head>
<body>
 <?php  require("adminNavbar.php");?>

    
    <img src="../image/c2.jpg" alt="photo" class="myattend">

    <!-- <div class="section">
        <h2>ABOUT EMPLOYEE ATTENDANCE SYSTEM</h2>
     </div> -->
           
        
<div class="footer">
     <p>© Employee Attendance System </p> 

    </div>

</body>s
</html><?php
    // session_start();
    // 
    // // Check if admin is logged in
    // if (!isset($_SESSION['admin_username'])) {
    //     header("Location: admin_login.php");
    //     exit();
    // }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial;
      background: #f5f5f5;
      padding: 40px;
    }

    .dashboard {
      max-width: 800px;
      margin: auto;
      background: white;
      border-radius: 10px;
      box-shadow: 0 0 10px #ccc;
      padding: 30px;
      text-align: center;
    }

    h1 {
      color: #333;
    }

    .nav-buttons a {
      display: inline-block;
      margin: 10px;
      padding: 15px 25px;
      background-color: skyblue;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }

    .nav-buttons a:hover {
      background-color: #3399cc;
    }
  </style>
</head>
<body>

<div class="dashboard">
  <h1>Welcome, Admin</h1>
  <div class="nav-buttons">
    <a href="admin_employees.php">Manage Employees</a>
    <a href="admin_attendance.php">Attendance Records</a>
    <a href="add_employee.php">Add Employee</a>
    <a href="logout.php">Logout</a>
  </div>
</div>

</body>
</html>
