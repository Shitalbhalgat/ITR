<?php
session_start();

// Check admin login
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}

// DB Connection
$conn = mysqli_connect("localhost", "root", "", "attendance_db");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Count total employees
$emp_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM employees");
$emp_count = mysqli_fetch_assoc($emp_result)['total'];

// Count total attendance entries
$att_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM attendance");
$att_count = mysqli_fetch_assoc($att_result)['total'];

// Count today's attendance
$today = date("Y-m-d");
$today_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM attendance WHERE date = '$today'");
$today_count = mysqli_fetch_assoc($today_result)['total'];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #007BFF;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }

        .dashboard-container {
            max-width: 1000px;
            margin: 40px auto;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .card {
            flex: 1;
            min-width: 250px;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
            text-align: center;
        }

        .card h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .card p {
            font-size: 28px;
            color: #007BFF;
            margin: 0;
        }

        .nav-links {
            text-align: center;
            margin-top: 40px;
        }

        .nav-links a {
            margin: 0 10px;
            text-decoration: none;
            background: #007BFF;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            font-weight: bold;
        }

        .nav-links a:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="header">
    ADMIN DASHBOARD
</div>

<div class="dashboard-container">
    <div class="card">
        <h2>Total Employees</h2>
        <p><?= $emp_count ?></p>
    </div>

    <div class="card">
        <h2>Total Attendance</h2>
        <p><?= $att_count ?></p>
    </div>

    <div class="card">
        <h2>Today's Attendance</h2>
        <p><?= $today_count ?></p>
    </div>
</div>

<div class="nav-links">
    <a href="admin_employees.php">Manage Employees</a>
    <a href="admin_attendance.php">View Attendance</a>
    <a href="add_employee.php">Add Employee</a>
    <a href="logout.php">Logout</a>
</div>

</body>
</html>
