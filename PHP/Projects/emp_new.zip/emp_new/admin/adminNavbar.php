<html>
<body>

    <div class="header">
        EMPLOYEE ATTENDANCE SYSTEM
    </div>

    <div class="navbar">
        <a href="adminhome.php">HOME</a>
       <a href="User_registration.php">ADD EMPLOYEE</a>
        <a href="ViewAll.php">VIEW_ALL_EMPLOYEE</a>
        <a href="adminreports.php">REPORT</a>
        <a href="adminlogin.php">LOGIN</a>
        <a href="logout.php">LOGOUT</a>
    
     </div>
</body>
</html>