<?php
session_start();

// Redirect if admin not logged in
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "attendance_db");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM employees";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Employees</title>
    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px #ccc;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: skyblue;
            color: white;
        }

        a.button {
            background: #28a745;
            color: white;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.button.delete {
            background: #dc3545;
        }

        .top-bar {
            text-align: right;
            margin-bottom: 10px;
        }

        .top-bar a {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border-radius: 4px;
            text-decoration: none;
        }

        .top-bar a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<h2>Employee List</h2>

<div class="top-bar">
    <a href="add_employee.php">+ Add New Employee</a>
</div>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Group</th>
            <th>DOB</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['mobile'] ?></td>
                    <td><?= $row['blood_group'] ?></td>
                    <td><?= $row['dob'] ?></td>
                    <td>
                        <a href="edit_employee.php?id=<?= $row['id'] ?>" class="button">Edit</a>
                        <a href="delete_employee.php?id=<?= $row['id'] ?>" class="button delete" onclick="return confirm('Are you sure to delete?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="7">No employees found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
