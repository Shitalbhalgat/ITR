<?php
$conn = new mysqli("localhost", "root", "", "employee_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
date_default_timezone_set('Asia/Kolkata'); // or your correct timezone

$employee_id = intval($_POST['employee_id']);
$action = $_POST['action'] ?? 'in'; // 'in' or 'out'
$date = date('Y-m-d');
$time = date('H:i:s');

// Check employee exists
$check = $conn->prepare("SELECT name FROM employees WHERE id = ?");
$check->bind_param("i", $employee_id);
$check->execute();
$check->store_result();
if ($check->num_rows === 0) {
    echo "Invalid QR code.";
    exit;
}
$check->bind_result($employee_name);
$check->fetch();

// Check if attendance exists for today
$att_stmt = $conn->prepare("SELECT id, time_in, time_out FROM attendance WHERE employee_id = ? AND date = ?");
$att_stmt->bind_param("is", $employee_id, $date);
$att_stmt->execute();
$att_stmt->store_result();

if ($att_stmt->num_rows === 0) {
    // No attendance record yet, insert new
    if ($action === 'in') {
        $insert = $conn->prepare("INSERT INTO attendance (employee_id, date, time_in) VALUES (?, ?, ?)");
        $insert->bind_param("iss", $employee_id, $date, $time);
        $insert->execute();
        echo "Clock In recorded for $employee_name at $time";
    } else {
        echo "You haven't clocked in yet!";
    }
} else {
    // Attendance record exists, update time_out if action = 'out'
    $att_stmt->bind_result($att_id, $time_in, $time_out);
    $att_stmt->fetch();

    if ($action === 'out') {
        if ($time_out === null) {
            $update = $conn->prepare("UPDATE attendance SET time_out = ? WHERE id = ?");
            $update->bind_param("si", $time, $att_id);
            $update->execute();
            echo "Clock Out recorded for $employee_name at $time";
        } else {
            echo "You already clocked out today!";
        }
    } else {
        echo "You already clocked in today!";
    }
}
