<?php
session_start();
require 'db_connection.php';
$error_message = "";
if (isset($_POST['s1']))
{
     $username = $_POST["username"];
     $password = $_POST["password"]; 
     $query = "SELECT * FROM employees WHERE Email= '$username' and password= '$password'";
     $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) === 1) 
        {
          $row = mysqli_fetch_assoc($result);
            $_SESSION['username'] = $username;
            header("Location:Qr-code-attendance.php");
            exit();
        } 
        
    else {
            $error_message = "Invalid username or password.";
        }
} 
mysqli_close($conn);
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Login Form</title>
<style>
        body, html {
                margin: 0;
                padding: 0; 
                height: 100%;
                font-family: Arial, sans-serif;
                background: #f5f5f5;
            }
        .container {
                display: flex;
                height: 100vh;
                max-width: 1200px;
                margin: auto;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
                border-radius: 10px;
                overflow: hidden;
                background: white;
        }

        .left-side {
                flex: 1;
                background-color: #4a90e2;
                border-top-left-radius: 10px;
                border-bottom-left-radius: 10px;
                display: flex;
                justify-content: center;
                align-items: center;
                text-align: center;
                padding: 20px;
        }

        .right-side {
                flex: 1;
                padding: 40px;
                display: flex;
                flex-direction: column;
                justify-content: center;
        }
        h2 {
           margin-bottom: 20px;
        }
        input[type="text"], input[type="password"] {
                width: 100%;
                padding: 12px;
                margin-bottom: 15px;
                font-size: 16px;
                border: 1px solid #ddd;
                border-radius: 5px;
        }
        input[type="submit"] {
                background: skyblue;
                color: white;
                padding: 12px;
                font-size: 16px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
        }


</style>
</head>
<body>

<div class="container">
    <div class="left-side">
        <div class="center-content">
            <h1 style="color:white;">Welcome Back!</h1>
            <p style="color:white;">Employee Attendance System</p>
        </div>
    </div>
    <div class="right-side">
        <h2>Login</h2>
       <form method="post" action="">
            <input type="text" name="username" placeholder="Enter username" required />
            <input type="password" name="password" placeholder="Enter password" required />
            <span style="color:red;"><?php if (!empty($error_message)): ?>
            <?php echo $error_message; ?>
            <?php endif; ?></span> <br><br>
            <input type="submit" value="Login" name="s1" >
        </form>

    </div>
</div>

</body>
</html>
