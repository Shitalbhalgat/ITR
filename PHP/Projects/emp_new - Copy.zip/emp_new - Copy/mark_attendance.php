<?php
require 'db_connection.php';
date_default_timezone_set('Asia/Kolkata');

$employee_id = intval($_POST['employee_id']);
$action = $_POST['action'] ?? 'in';
$date = date('Y-m-d');
$time = date('H:i:s');


$current_time = date("H:i"); // Current time in 24-hour format, e.g., "14:30"
$start_time = "08:30";
$end_time = "09:15";

// Check if current time is within allowed time range
if ($current_time < $start_time || $current_time > $end_time) {
    echo "Attendance allowed only between 8:30 AM and 9:15 AM.";
    exit;
}
// 1. Check if employee exists
$employee_id_escaped =  $employee_id;
$emp_sql = "SELECT name FROM employees WHERE id = '$employee_id_escaped'";
$emp_result = mysqli_query($conn, $emp_sql);

if (mysqli_num_rows($emp_result) === 0) {
    echo "Invalid QR code.";
    exit;
}
$employee_row = mysqli_fetch_assoc($emp_result);
$employee_name = $employee_row['name'];

// 2. Check if today's attendance exists
$att_sql = "SELECT id, time_in, time_out FROM attendance WHERE employee_id = '$employee_id_escaped' AND date = '$date'";
$att_result = mysqli_query($conn, $att_sql);

if (mysqli_num_rows($att_result) === 0) {
    // No record yet, insert if action is 'in'
    if ($action === 'in') {
        $insert_sql = "INSERT INTO attendance (employee_id, date, time_in) VALUES ('$employee_id_escaped', '$date', '$time')";
        if (mysqli_query($conn, $insert_sql)) {
            echo "Clock In recorded for $employee_name at $time";
        } else {
            echo "Error recording clock in.";
        }
    } else {
        echo "You haven't clocked in yet!";
    }
} else {
    // Record exists
    $att_row = mysqli_fetch_assoc($att_result);
    $att_id = $att_row['id'];
    $time_in = $att_row['time_in'];
    $time_out = $att_row['time_out'];

    if ($action === 'out') {
        if (empty($time_out)) {
            $update_sql = "UPDATE attendance SET time_out = '$time' WHERE id = '$att_id'";
            if (mysqli_query($conn, $update_sql)) {
                echo "Clock Out recorded for $employee_name at $time";
            } else {
                echo "Error recording clock out.";
            }
        } else {
            echo "You already clocked out today!";
        }
    } else {
        echo "You already clocked in today!";
    }
}
?>
