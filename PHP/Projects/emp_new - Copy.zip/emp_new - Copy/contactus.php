<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - Employee Attendance System</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .contact-container {
      max-width: 800px;
      margin: 50px auto;
      padding: 30px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px #ccc;
      font-family: Arial, sans-serif;
    }

    h1 {
      color: #007BFF;
      text-align: center;
    }

    label {
      display: block;
      margin-top: 15px;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    input[type="submit"] {
      background-color:#00aaFF;
      color: white;
      font-weight: bold;
      margin-top: 20px;
      cursor: pointer;
    }
  </style>
</head>
<body>

<?php include("Navbar.php"); ?>

<div class="contact-container">
     <h1>Contact Us</h1>
    <form method="post" action="">
    <label>Name</label>
    <input type="text" name="name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Message</label>
    <textarea name="message" rows="5" required></textarea>

    <input type="submit" name="submit" value="Send Message">
  </form>
</div>

<div class="footer">
  <p>© Employee Attendance System</p>
</div>


</body>
</html>
<?php include("Navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
    .contact-section {
      max-width: 600px;
      margin: 4rem auto;
      padding: 2rem;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
    h1 { color: #0052cc; font-weight: 700; margin-bottom: 1rem; }
    label { font-weight: 600; }
  </style>
</head>
<body>

  <div class="contact-section">
    <h1>Contact Us</h1>
    <form>
      <div class="mb-3">
        <label for="name" class="form-label">Your Name</label>
        <input type="text" class="form-control" id="name" placeholder="Full Name">
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Your Email</label>
        <input type="email" class="form-control" id="email" placeholder="you@example.com">
      </div>
      <div class="mb-3">
        <label for="message" class="form-label">Your Message</label>
        <textarea class="form-control" id="message" rows="4" placeholder="How can we help?"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">
        <i class="bi bi-send"></i> Send Message
      </button>
    </form>
  </div>

</body>
</html>
