<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Employee Attendance System</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="style.css" rel="stylesheet">

  <style>
    /* Container */
    .container-main {
      max-width: 1100px;
      margin: 2.5rem auto 4rem;
      padding: 0 1rem;
    }

    /* Header */
    .header-section {
      margin-bottom: 2.5rem;
    }
    .header-section h1 {
      font-weight: 700;
      font-size: 2.5rem;
      margin-bottom: 0.5rem;
      color: #222;
    }
    .header-section p {
      color: #6b7280; 
      font-size: 1.1rem;
    }

    /* Cards layout */
    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(280px,1fr));
      gap: 1.75rem;
    }

    /* Card style */
    .card-custom {
      background: white;
      border-radius: 12px;
      padding: 1.8rem 2rem;
      box-shadow: 0 4px 15px rgb(0 0 0 / 0.08);
      transition: box-shadow 0.3s ease, transform 0.3s ease;
      cursor: default;
      display: flex;
      flex-direction: column;
    }
    .card-custom:hover {
      box-shadow: 0 6px 25px rgb(0 0 0 / 0.15);
      transform: translateY(-6px);
    }
    .card-custom h2 {
      font-weight: 700;
      font-size: 1.4rem;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 0.6rem;
      color: #0052cc;
    }
    .card-custom ul {
      list-style: none;
      padding-left: 0;
      margin-bottom: 0;
      color: #4b5563;
      font-size: 1rem;
    }
    .card-custom ul li {
      margin-bottom: 0.9rem;
      display: flex;
      align-items: center;
      gap: 0.6rem;
    }
    .card-custom ul li i {
      color: #0052cc;
      font-size: 1.2rem;
      flex-shrink: 0;
    }

    /* FAQ */
    .accordion-button {
      font-weight: 600;
      color: #1f2937;
      font-size: 1rem;
    }
    .accordion-button:not(.collapsed) {
      color: #0052cc;
      background-color: #e0e7ff;
      box-shadow: none;
    }
    .accordion-body {
      color: #4b5563;
      font-size: 0.95rem;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav>
    <a href="#" class="brand">
      <i class="bi bi-clipboard-check-fill"></i> AttendanceSystem
    </a>
    <div class="nav-links">
              <?php require("Navbar.php"); ?>
     </div>
     <?php if (!isset($_SESSION['username'])): ?>
                <a href="userlogin.php" class="btn-login">
                 <i class="bi bi-box-arrow-in-right"></i> Login</a>
        <?php else: ?>
                <a href="logout.php" class="btn-login">
        <i class="bi bi-box-arrow-in-right"></i> Logout
    </a>
        <?php endif; ?>
   
  </nav>

  <main class="container-main">
    <section class="header-section text-center">
      <h1>Employee Attendance Dashboard</h1>
      <p>Efficient. Transparent. Mobile-friendly.</p>
    </section>

    <section class="cards-grid">
      <article class="card-custom">
        <h2><i class="bi bi-gear"></i> How It Works</h2>
        <ul>
          <li><i class="bi bi-box-arrow-in-right"></i> Log in with your employee credentials.</li>
          <li><i class="bi bi-check2-square"></i> Tap Check In  at the start of your shift.</li>
          <li><i class="bi bi-clock"></i> Tap Check Out at the end of your shift.</li>
          <li><i class="bi bi-calendar-range"></i> View history from the Attendance tab.</li>
        </ul>
      </article>

      <article class="card-custom">
        <h2><i class="bi bi-pencil-square"></i><a href="Qr-code-attendance.php" style="color:#0052cc; text-decoration: none;">Mark Your Attendance</a></h2>
        <ul>
          <li><i class="bi bi-house-door"></i> Navigate to the Dashboard after login.</li>
          <li><i class="bi bi-person-check"></i> Click the Check In button.</li>
          <li><i class="bi bi-person-dash"></i> At shift end, click Check Out.</li> 
        </ul>
      </article>

      <article class="card-custom">
        <h2><i class="bi bi-question-circle"></i> FAQs</h2>
        <div class="accordion" id="faqAccordion">
          <div class="accordion-item">
            <h2 class="accordion-header" id="q1">
              <button
                class="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#faq1"
                aria-expanded="false"
                aria-controls="faq1"
              >
                What if I forget to check in?
              </button>
            </h2>
            <div
              id="faq1"
              class="accordion-collapse collapse"
              data-bs-parent="#faqAccordion"
            >
              <div class="accordion-body">
                Request a manual entry via HR or use the “Request Correction” button.
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header" id="q2">
              <button
                class="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#faq2"
                aria-expanded="false"
                aria-controls="faq2"
              >
                Can I edit my attendance?
              </button>
            </h2>
            <div
              id="faq2"
              class="accordion-collapse collapse"
              data-bs-parent="#faqAccordion"
            >
              <div class="accordion-body">
                No. All changes must go through HR approval to ensure data integrity.
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header" id="q3">
              <button
                class="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#faq3"
                aria-expanded="false"
                aria-controls="faq3"
              >
                How do I verify if my attendance is recorded?
              </button>
            </h2>
            <div
              id="faq3"
              class="accordion-collapse collapse"
              data-bs-parent="#faqAccordion"
            >
              <div class="accordion-body">
                Go to Attendance History from your profile. Status icons indicate if entries are complete.
              </div>
            </div>
          </div>
        </div>
      </article>
    </section>
  </main>


<!-- About Us Section -->
<section class="bg-white py-5 mt-5 border-top">
  <div class="container">
    <div class="row justify-content-center text-center">
      <div class="col-lg-8">
        <h2 class="fw-bold text-primary mb-3">About Our System</h2>
        <p class="text-muted fs-6">
          The Employee Attendance System is designed to help businesses of all sizes simplify how they track time, attendance, and productivity.
          Our goal is to provide a reliable and user-friendly platform that empowers HR teams and employees alike.
        </p>
        <p class="text-muted fs-6">
          Built with efficiency, transparency, and mobile-responsiveness in mind — our system ensures seamless daily check-ins, secure records, and easy reporting.
        </p>
      </div>
    </div>
  </div>
</section>
<!-- Contact Us Section -->
<section class="bg-light py-5 border-top">
  <div class="container">
    <div class="row justify-content-center text-center mb-4">
      <div class="col-lg-8">
        <h2 class="fw-bold text-primary mb-3">Contact Us</h2>
        <p class="text-muted fs-6">
          Have questions or need support? Reach out and we’ll get back to you shortly.
        </p>
      </div>
    </div>

    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6">
        <form action="contact_submit.php" method="POST">
          <div class="mb-3">
            <label for="name" class="form-label fw-semibold">Your Name</label>
            <input type="text" name="name" id="name" class="form-control" required placeholder="Enter your name">
          </div>
          <div class="mb-3">
            <label for="email" class="form-label fw-semibold">Email Address</label>
            <input type="email" name="email" id="email" class="form-control" required placeholder="john@example.com">
          </div>
          <div class="mb-3">
            <label for="message" class="form-label fw-semibold">Message</label>
            <textarea name="message" id="message" class="form-control" rows="4" required placeholder="Write your message..."></textarea>
          </div>
          <div class="d-grid">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-send-fill me-1"></i> Send Message
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

  <footer>
    &copy; <?= date("Y") ?> Employee Attendance System. All rights reserved.
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
