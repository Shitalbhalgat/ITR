<?php
session_start();
require "db_connection.php";

if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}


$sql = "SELECT * FROM employees";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Manage Employees</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../CSS/style.css" rel ="stylesheet"/>
  <style>
  .content {
      flex-grow: 1;
      padding: 30px;
    }

    .table-container {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px #ccc;
    }

    .btn-add {
      background-color: #007BFF;
      color: white;
    }

    .btn-add:hover {
      background-color: #0056b3;
    }

    .btn-edit {
      background-color: #28a745;
      color: white;
    }

    .btn-edit:hover {
      background-color: #218838;
    }

    .btn-delete {
      background-color: #dc3545;
      color: white;
    }

    .btn-delete:hover {
      background-color: #c82333;
    }
  </style>
</head>
<body>


 <?php require_once 'adminNavbar.php'; ?>

  <!-- Main Content -->
  <div class="content">
    <nav class="navbar navbar-expand navbar-light bg-light mb-4">
      <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">Manage Employees</span>
      </div>
    </nav>

    <div class="table-container">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Employee List</h4>
        <a href="addemp.php" class="btn btn-add">+ Add New Employee</a>
      </div>

      <table class="table table-bordered table-striped">
        <thead class="table-primary text-center">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Department</th>
            <th>Designation</th>
            <th>QR Code</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="text-center">
          <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= $row['Email'] ?></td>
                <td><?= $row['mobile'] ?></td>
                <td><?= $row['department'] ?></td>
                <td><?= $row['designation'] ?></td>
                <td>
    <?php if (!empty($row['qr_code'])): ?>
      <img src="<?= $row['qr_code'] ?>" alt="QR Code" style="width: 60px;" />
    <?php else: ?>
      N/A
    <?php endif; ?>
  </td>

                <td>
                  <a href="edit_employee.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-edit">Edit</a>
                  <a href="delete_employee.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-delete" onclick="return confirm('Are you sure you want to delete this employee?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="7">No employees found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
