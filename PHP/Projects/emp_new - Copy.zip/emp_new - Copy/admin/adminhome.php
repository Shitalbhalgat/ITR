<?php
session_start();
require "db_connection.php";
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}


 // Total employees
$emp_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM employees");
$emp_count = mysqli_fetch_assoc($emp_result)['total'];

// Total attendance entries
$att_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM attendance");
$att_count = mysqli_fetch_assoc($att_result)['total'];

// Today's attendance
$today = date("Y-m-d");
$today_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM attendance WHERE date = '$today'");
$today_count = mysqli_fetch_assoc($today_result)['total'];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Dashboard</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../CSS/style.css" rel ="stylesheet"/>

  <style>
    

    .content {
      flex-grow: 1;
      padding: 30px;
      background: #f5f5f5;
    }


    .nav-buttons a {
      display: inline-block;
      margin: 10px;
      padding: 15px 25px;
      background-color: skyblue;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }

    .nav-buttons a:hover {
      background-color: #3399cc;
    }

    .card h5 {
      font-size: 18px;
    }

    .card p {
      font-size: 26px;
      margin-top: 10px;
    }

  </style>
</head>
<body>
<?php require_once 'adminNavbar.php'; ?>

  <!-- Main Content -->
  <div class="content">
    <nav class="navbar navbar-expand navbar-light bg-light mb-4">
      <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">Dashboard</span>
      </div>
    </nav>

   

    <!-- Stats Cards -->
    <div class="row g-4 mb-5">
      <div class="col-md-4">
        <div class="card text-bg-primary text-center">
          <div class="card-body">
            <h5 class="card-title">Total Employees</h5>
            <p><?= $emp_count ?></p>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card text-bg-success text-center">
          <div class="card-body">
            <h5 class="card-title">Total Attendance</h5>
            <p><?=$att_count ?></p>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card text-bg-warning text-center">
          <div class="card-body">
            <h5 class="card-title">Today's Attendance</h5>
            <p><?= $today_count ?></p>
          </div>
        </div>
      </div>
    </div>

    
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
