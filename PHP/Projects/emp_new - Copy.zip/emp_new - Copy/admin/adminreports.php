
<?php
session_start();

require "db_connection.php";

if (!isset($_SESSION['admin_username'])) {
    header("Location: adminlogin.php");
    exit();
}

$sql = "SELECT a.id, a.date, a.time_in, a.time_out, e.name, e.email 
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        ORDER BY a.date DESC, a.time_in DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin - Attendance Records</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../CSS/style.css" rel="stylesheet" />

    <style>
        body {
            background: #f5f5f5;
        }

        .content {
            padding: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        table {
            background: #fff;
            box-shadow: 0 0 10px #ccc;
        }

        th {
            background: skyblue;
            color: white;
        }

        .no-records {
            text-align: center;
            padding: 20px;
            font-weight: bold;
            color: red;
        }

        .back-link {
            text-align: center;
            margin-top: 25px;
        }

        .back-link a {
            text-decoration: none;
            color: #007BFF;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<?php require_once 'adminNavbar.php'; ?>

<div class="content container">
    <nav class="navbar navbar-expand navbar-light bg-light mb-4">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">Attendance Records</span>
        </div>
    </nav>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
            <thead>
                <tr>
                    <th>Record ID</th>
                    <th>Employee Name</th>
                    <th>Email</th>
                    <th>Date</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= $row['date'] ?></td>
                            <td><?= $row['time_in'] ?></td>
                            <td><?= $row['time_out'] ?? '-' ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="no-records">No attendance records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

  
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
