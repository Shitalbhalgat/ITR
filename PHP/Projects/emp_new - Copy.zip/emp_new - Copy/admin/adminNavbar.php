 <div class="sidebar">
    <h4 class="text-center">Admin Panel</h4>
    <a href="adminhome.php">Dashboard</a>
    <a href="View_All.php">Manage Employees</a>
    <a href="adminreports.php">Attendance Records</a>
    <a href="addemp.php">Add Employee</a>
    <a href="logout.php">Logout</a>
  </div>