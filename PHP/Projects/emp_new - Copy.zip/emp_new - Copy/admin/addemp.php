<?php
session_start();
require "db_connection.php";
include 'phpqrcode/qrlib.php';

if (!isset($_SESSION['admin_username'])) {
    header("Location: adminlogin.php");
    exit();
}

$success = "";
$error = "";

if (isset($_POST['s1']) ) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $department = $_POST['department'];
    $designation = $_POST['designation'];
    $password = $_POST['password'];

    if ($name && $email && $mobile && $department && $designation && $password)
         {
        $sql = "INSERT INTO employees (name, email, mobile, department, designation, password)
                VALUES ('$name', '$email', '$mobile', '$department', '$designation', '$password')";
        if (mysqli_query($conn, $sql)) {
            $last_id = mysqli_insert_id($conn);

            // Generate QR code
            $qrText = $last_id;
            $qrDir = 'qrcodes/';
            if (!file_exists($qrDir)) {
                mkdir($qrDir, 0777, true); 
            }

            $qrFileName = $qrDir . 'emp_' . $last_id . '.png';
            QRcode::png($qrText, $qrFileName, QR_ECLEVEL_L, 4);

            //  Save QR path to database
            $update = "UPDATE employees SET qr_code = '$qrFileName' WHERE id = $last_id";
            mysqli_query($conn, $update);

            $success = "Employee added successfully. QR Code generated.";
            

        } else {
            $error = "Database error: " . mysqli_error($conn);
        }
    } else {
        $error = "Please fill all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Add Employee</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../CSS/style.css" rel ="stylesheet"/>

  <style>
    .content {
      flex-grow: 1;
      padding: 30px;
    }

    .form-container {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px #ccc;
      max-width: 700px;
      margin: auto;
    }

    .form-container h3 {
      margin-bottom: 25px;
      color: #007BFF;
    }
  </style>
</head>
<body>

 <?php require_once 'adminNavbar.php'; ?>


  <div class="content">
    <div class="form-container">
      <h3>Add New Employee</h3>

      <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php elseif ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" required />
        </div>

        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" required />
        </div>

        <div class="mb-3">
          <label class="form-label">Mobile</label>
          <input type="text" name="mobile" class="form-control" required />
        </div>

        <div class="mb-3">
          <label class="form-label">Department</label>
          <select name="department" class="form-select" required>
            <option value="">-- Select Department --</option>
            <option value="HR">HR</option>
            <option value="IT">IT</option>
            <option value="Sales">Sales</option>
            <option value="Marketing">Marketing</option>
            <option value="Finance">Finance</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Designation</label>
          <select name="designation" class="form-select" required>
            <option value="">-- Select Designation --</option>
            <option value="Manager">Manager</option>
            <option value="Team Lead">Team Lead</option>
            <option value="Executive">Executive</option>
            <option value="Intern">Intern</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required />
        </div>

        <button type="submit" class="btn btn-primary" name="s1">Add Employee</button>
        <a href="adminhome.php" class="btn btn-secondary">Cancel</a>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
