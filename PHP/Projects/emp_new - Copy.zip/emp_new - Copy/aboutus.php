<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Us - Employee Attendance System</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #f4f4f4;
      color: #333;
    }

    .about-container {
      max-width: 900px;
      margin: 40px auto;
      background: white;
      padding: 40px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 10px;
    }

    h1, h2 {
      color: #007BFF;
      text-align: center;
    }

    p {
      line-height: 1.6;
      margin-bottom: 20px;
    }

    .team-section {
      margin-top: 40px;
    }

    .team-member {
      margin-bottom: 15px;
    }

   
  </style>
</head>
<body>

<?php include('Navbar.php'); ?>

<div class="about-container">
  <h1>About Us</h1>
  <p>
    Welcome to the <strong>Employee Attendance System</strong> — a simple and efficient platform built to manage and track employee attendance digitally using modern web technologies and QR code scanning.
  </p>

  <p>
    This system ensures accurate clock-ins and clock-outs, eliminates manual record-keeping, and provides easy access to reports and attendance history. Whether you're an HR manager or a small business owner, our system helps streamline daily operations.
  </p>

  <p>
    Thank you for using our system!
  </p>

  <h2 class="team-section">Meet the Team</h2>

  <div class="team-member"><strong>Mrunal More</strong> — Developer</div>
  <div class="team-member"><strong>Samrin Pathan</strong> — Designer</div>
  <div class="team-member"><strong>Sanika Pawar</strong> — QA & Testing</div>

</div>

<div class="footer">
  <p>© Employee Attendance System</p>
</div>

</body>
</html>
<?php include("Navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Us</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
    .about-section {
      max-width: 900px;
      margin: 4rem auto;
      padding: 2rem;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
    h1 { color: #0052cc; font-weight: 700; }
    p { color: #555; font-size: 1rem; line-height: 1.6; }
  </style>
</head>
<body>

  <div class="about-section">
    <h1>About Our Attendance System</h1>
    <p>
      Our Employee Attendance System is a smart, efficient, and transparent solution designed for businesses that value accountability and productivity. 
      We help organizations keep track of working hours, manage attendance records, and generate reports — all in one dashboard.
    </p>
    <p>
      Built with a mobile-first approach, this platform ensures that employees can check in/out anytime, anywhere. HR teams can access real-time data, make corrections, and generate insights.
    </p>
    <p>
      We are committed to delivering reliable software that supports both small businesses and large enterprises.
    </p>
  </div>

</body>
</html>
