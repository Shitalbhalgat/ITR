 
        <a href="index.php">Home</a>
        <a href="Qr-code-attendance.php">Mark Attendance</a>
        <a href="userreports.php">Attendance History</a>
        <a href="profile.php">Profile</a>
