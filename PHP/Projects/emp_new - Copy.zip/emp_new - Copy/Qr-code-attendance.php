<?php
session_start();

if (!isset($_SESSION['username'])) 
  {
    header("Location: userlogin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>QR Code Attendance</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="style.css" rel="stylesheet">

  <!-- QR Code Scanner -->
 <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>

  <style>
  

    .container-main {
      max-width: 900px;
      margin: 2.5rem auto 4rem;
      padding: 0 1rem;
    }

    .header-section {
      margin-bottom: 2.5rem;
    }

    .header-section h1 {
      font-weight: 700;
      font-size: 2.2rem;
      /* color: #222; */
      color: #0052cc;
    }

    .card-custom {
      background: white;
      border-radius: 12px;
      padding: 2rem;
      box-shadow: 0 4px 15px rgb(0 0 0 / 0.08);
      transition: 0.3s;
    }

    .card-custom:hover {
      box-shadow: 0 6px 25px rgb(0 0 0 / 0.15);
    }

    #reader {
      width: 100%;
      max-width: 500px;
      margin: 0 auto;
    }

    .btn-toggle {
      margin: 0 10px;
    }

    #result {
      margin-top: 20px;
      font-weight: 600;
      font-size: 1.1rem;
    }

    footer {
      text-align: center;
      padding: 1.5rem 0;
      margin-top: 3rem;
      background: #f1f5f9;
      color: #4b5563;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav>
    <a href="#" class="brand">
      <i class="bi bi-clipboard-check-fill"></i> AttendanceSystem
    </a>
    <div class="nav-links">
      <?php require("Navbar.php"); ?>
    </div>
    <?php if (!isset($_SESSION['username'])): ?>
                <a href="userlogin.php" class="btn-login">
                 <i class="bi bi-box-arrow-in-right"></i> Login</a>
        <?php else: ?>
                <a href="logout.php" class="btn-login">
        <i class="bi bi-box-arrow-in-right"></i> Logout
    </a>
        <?php endif; ?>
  </nav>

  <!-- Main Content -->
  <main class="container-main">
    <section class="header-section text-center">
      <h1>QR Code Attendance</h1>
      <p>Scan your employee QR code to mark attendance.</p>
    </section>

    <section class="card-custom text-center">
      <div class="mb-4">
        <button id="inBtn" class="btn btn-success btn-toggle"><i class="bi bi-box-arrow-in-right me-1"></i> Clock In</button>
        <button id="outBtn" class="btn btn-danger btn-toggle"><i class="bi bi-box-arrow-left me-1"></i> Clock Out</button>
      </div>

      <div id="reader"></div>
      <div id="result" class="mt-3 text-center" style="color: #0052cc;">Select an action and scan your QR code</div>
    </section>
  </main>

  <!-- Footer -->
  <footer>
    &copy; <?= date("Y") ?> Employee Attendance System. All rights reserved.
  </footer>

  <!-- JavaScript -->
  <script>
    let lastScannedId = null;
    let currentAction = 'in';

    document.getElementById('inBtn').onclick = (e) => {
      e.preventDefault();
      currentAction = 'in';
      document.getElementById('result').innerText = "Ready to Clock In - Scan QR";
    };

    document.getElementById('outBtn').onclick = (e) => {
      e.preventDefault();
      currentAction = 'out';
      document.getElementById('result').innerText = "Ready to Clock Out - Scan QR";
    };

    function onScanSuccess(qrCodeMessage) {
      if (qrCodeMessage === lastScannedId) return;
      lastScannedId = qrCodeMessage;

      fetch('mark_attendance.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'employee_id=' + encodeURIComponent(qrCodeMessage) + '&action=' + currentAction
      })
      .then(response => response.text())
      .then(data => {
        const resultDiv = document.getElementById('result');
        const success = data.toLowerCase().includes("recorded");

        resultDiv.innerText = data;
        resultDiv.style.color = success ? 'green' : 'red';

        setTimeout(() => {
          lastScannedId = null;
        }, 3000);
      });
    }

    const html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
    html5QrcodeScanner.render(onScanSuccess);
  </script>
</body>
</html>
