<?php 
require('db_connection.php');
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: userlogin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Employee Reports</title>

  <!-- Bootstrap + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="style.css" rel="stylesheet">

  <style>
.container-main {
      max-width: 1100px;
      margin: 3rem auto;
      padding: 0 1rem;
    }

    .header-section {
      margin-bottom: 2.5rem;
      text-align: center;
    }

    .header-section h2 {
      font-weight: 700;
      font-size: 2rem;
      color: #222;
    }

    .card-custom {
      background: white;
      border-radius: 12px;
      padding: 2rem;
      box-shadow: 0 4px 15px rgb(0 0 0 / 0.08);
    }

    .table thead {
      background-color: #0d6efd;
      color: white;
    }

    .table th, .table td {
      vertical-align: middle;
    }


  </style>
</head>
<body>

  <!-- Navbar -->
  <nav>
    <a href="#" class="brand">
      <i class="bi bi-clipboard-check-fill"></i> AttendanceSystem
    </a>
    <div class="nav-links">
      <?php require("Navbar.php"); ?>
    </div>
    <?php if (!isset($_SESSION['username'])): ?>
                <a href="userlogin.php" class="btn-login">
                 <i class="bi bi-box-arrow-in-right"></i> Login</a>
        <?php else: ?>
                <a href="logout.php" class="btn-login">
        <i class="bi bi-box-arrow-in-right"></i> Logout
    </a>
        <?php endif; ?>
  </nav>

  <!-- Main Content -->
  <main class="container-main">
    <section class="header-section">
      <h2 style="color: #0052cc;">Employee Reports</h2>
    </section>

    <section class="card-custom">
      <div class="table-responsive">
        <table class="table table-bordered align-middle text-center">
          <thead>
            <tr>
              <th>Sr. No.</th>
              <th>Employee Name</th>
              <th>Date</th>
              <th>Time In</th>
              <th>Time Out</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $username = $_SESSION['username'];
              $query = "SELECT attendance.id,
                          employees.name,
                          attendance.date,
                          attendance.time_in,
                          attendance.time_out
                        FROM attendance
                        JOIN employees ON attendance.employee_id = employees.id 
                        WHERE employees.name = '$username'";

              $result = mysqli_query($conn, $query);
              $sr = 1;

              if (mysqli_num_rows($result) > 0) {
                  while ($row = mysqli_fetch_assoc($result)) {
                      echo "<tr>
                              <td>{$sr}</td>
                              <td>{$row['name']}</td>
                              <td>{$row['date']}</td>
                              <td>{$row['time_in']}</td>
                              <td>{$row['time_out']}</td>
                            </tr>";
                      $sr++;
                  }
              } else {
                  echo "<tr><td colspan='5'>No attendance records found.</td></tr>";
              }

              mysqli_close($conn);
            ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <!-- Footer -->
  <footer>
    &copy; <?= date("Y") ?> Employee Attendance System. All rights reserved.
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
