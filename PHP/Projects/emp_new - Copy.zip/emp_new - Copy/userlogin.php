<?php
session_start();
require 'db_connection.php';

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $username =  $username;
    $password =  $password;

    $query = "SELECT * FROM employees WHERE Email = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $_SESSION['username'] = $username;
        header("Location: Qr-code-attendance.php");
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }

    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - Employee Attendance System</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f9fafb;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .login-container {
      background-color: #ffffff;
      padding: 3rem;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
      width: 100%;
      max-width: 400px;
    }

    .login-title {
      font-size: 1.8rem;
      font-weight: 700;
      color: #0052cc;
      text-align: center;
      margin-bottom: 1.5rem;
    }

    .form-label {
      font-weight: 600;
      color: #1f2937;
    }

    .form-control {
      border-radius: 8px;
      padding: 0.65rem;
      font-size: 0.95rem;
    }

    .form-control:focus {
      border-color: #0052cc;
      box-shadow: 0 0 0 0.2rem rgba(0, 82, 204, 0.2);
    }

    .btn-login {
      background-color: #0052cc;
      color: #fff;
      font-weight: 600;
      border: none;
      padding: 0.65rem;
      border-radius: 8px;
      width: 100%;
      transition: background-color 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      font-size: 1rem;
    }

    .btn-login:hover {
      background-color: #003d99;
    }

    .text-muted {
      text-align: center;
      margin-top: 1rem;
      font-size: 0.9rem;
      color: #6b7280;
    }

    .error-message {
      color: red;
      font-size: 0.9rem;
      text-align: center;
      margin-bottom: 1rem;
    }
  </style>
</head>
<body>

  <div class="login-container">
    <div class="login-title">
      <i class="bi bi-box-arrow-in-right me-2"></i>
      Employee Login
    </div>

    <?php if (!empty($error_message)): ?>
      <div class="error-message"><?= $error_message ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="mb-3">
        <label for="username" class="form-label">Email</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="Enter your email" required>
      </div>

      <div class="mb-4">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
      </div>

      <button type="submit" name="s1" class="btn btn-login">
        <i class="bi bi-box-arrow-in-right"></i> Login
      </button>
    </form>

    <div class="text-muted">
      Forgot password? Contact your administrator.
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
