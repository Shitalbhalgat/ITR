<?php 
session_start();
require('db_connection.php');

if (!isset($_SESSION['username'])) {
    header("Location: userlogin.php");
    exit();
}

$username = $_SESSION['username'];
$query = "SELECT * FROM employees WHERE Email = '$username'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("User not found.");
}

$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>My Profile</title>

  <!-- Bootstrap + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="style.css" rel="stylesheet" />

  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f8fafc;
    }

    .profile-wrapper {
      max-width: 1000px;
      margin: 3rem auto;
      background: white;
      box-shadow: 0 4px 20px rgba(0,0,0,0.05);
      border-radius: 12px;
      overflow: hidden;
    }

    .profile-left {
      background-color: #0052cc;
      color: white;
      padding: 2rem 1.5rem;
      text-align: center;
    }

    .profile-left img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid white;
      margin-bottom: 15px;
    }

    .profile-left h3 {
      font-weight: 700;
    }

    .profile-right {
      padding: 2rem;
    }

    .profile-info p {
      font-size: 1rem;
      margin: 12px 0;
      color: #374151;
    }

    .profile-info span {
      font-weight: 600;
      color: #111827;
      display: inline-block;
      width: 140px;
    }

    footer {
      text-align: center;
      padding: 1.5rem 0;
      background-color: #f1f5f9;
      margin-top: 3rem;
      color: #4b5563;
    }

    @media (max-width: 768px) {
      .profile-left, .profile-right {
        padding: 1.5rem;
      }
      .profile-info span {
        display: block;
        width: auto;
        margin-bottom: 5px;
      }
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav>
  <a href="#" class="brand">
    <i class="bi bi-clipboard-check-fill"></i> AttendanceSystem
  </a>
  <div class="nav-links">
    <?php include("Navbar.php"); ?>
  </div>
  <a href="userlogin.php" class="btn-login">
    <i class="bi bi-box-arrow-in-right"></i> Login
  </a>
</nav>

<!-- Profile Content -->
<div class="profile-wrapper d-md-flex">
  <!-- Left Column -->
  
<div class="profile-left col-md-4">
    <?php echo 'admin/' . $user['qr_code'];
    echo "<img src='admin/" . $user['qr_code'] . "' alt='QR Code'>  " ?>

<img src="<?php echo !empty($user['qr_code']) ? '/admin/' . $user['qr_code'] : 'default_qr.png'; ?>" alt="QR Code">
  <h3><?php echo $user['name']; ?></h3>
  <p class="small">Employee</p>
</div>


  <!-- Right Column -->
  <div class="profile-right col-md-8">
    <h4 class="mb-4 fw-bold">Profile Information</h4>
    <div class="profile-info">
  <p><span>Name:</span> <?php echo $user['name']; ?></p>
  <p><span>Email:</span> <?php echo $user['Email']; ?></p>
  <p><span>Mobile:</span> <?php echo !empty($user['mobile']) ? $user['mobile'] : 'N/A'; ?></p>
  <p><span>Department:</span> <?php echo !empty($user['department'])? $user['department'] : 'N/A'; ?></p>
  <p><span>Designation:</span> <?php echo !empty($user['designation']) ? $user['designation'] : 'N/A'; ?></p>

</div>

  </div>
</div>

<!-- Footer -->
<footer>
  &copy; <?= date("Y") ?> Employee Attendance System. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

